//
//  ContentView.swift
//  Steam
//
//  Created by Kavsoft on 22/12/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        TabView{
            
            Home().tabItem {
                
                Image("home")
            }
            
            Text("Search").tabItem {
                
                Image("search")
            }
            
            Text("Person").tabItem {
                
                Image("person")
            }
            
            Text("Menu").tabItem {
                
                Image("menu")
            }
            
        }.accentColor(.white)
        .preferredColorScheme(.dark)
        .edgesIgnoringSafeArea(.top)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    
    var body : some View{
        
        VStack(spacing: 15){
            
            HStack{
                
                Text("$89")
                
                Spacer()
                
                Button(action: {
                    
                }) {
                    
                    Image("Cart")
                }
                
            }.overlay(Image("Logo"))
            
            ScrollView(.vertical, showsIndicators: false) {
                
                topView().padding(.vertical,15)
                middleView()
                bottomView().padding(.top, 15)
            }
  
        }.padding()
    }
}


struct topView : View {
    
    @State var show = false
    
    var body : some View{
        
        VStack(alignment: .leading, spacing: 15){
            
            Text("Featured").font(.title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15){
                    
                    ForEach(top,id: \.self){i in
                        
                        Image(i).onTapGesture {
                            
                            self.show.toggle()
                        }
                    }
                }
                
            }.padding(.top,15)
            
        }.sheet(isPresented: $show) {
            
            Detail()
        }
    }
}

struct middleView : View {
    
    var body : some View{
        
        VStack(alignment: .leading, spacing: 15){
            
            Text("New On Steam").font(.title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15){
                    
                    ForEach(middle,id: \.self){i in
                        
                        Image(i)
                    }
                }
                
            }.padding(.top,15)
        }
    }
}

struct bottomView : View {
    
    var body : some View{
        
        VStack(alignment: .leading, spacing: 15){
            
            Text("Recommended").font(.title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15){
                    
                    ForEach(bottom,id: \.self){i in
                        
                        Image(i)
                    }
                }
                
            }.padding(.top,15)
        }
    }
}

struct Detail : View {
    
    @State var selected = "About"
    
    var body : some View{
        
        VStack(spacing : 0){
            
            Image("Header")
            
            ZStack{
                
                VStack(spacing: 20){
                    
                    HStack(spacing: 25){
                        
                        Button(action: {
                            
                            self.selected = "About"
                            
                        }) {
                            
                            Text("About").padding(.vertical,15).padding(.horizontal, 22)
                            
                        }.background(self.selected == "About" ? Color("Color") : Color.clear)
                        .foregroundColor(self.selected == "About" ? .white : Color.gray)
                        .cornerRadius(15)
                        
                        Button(action: {
                            
                            self.selected = "Media"
                            
                        }) {
                            
                            Text("Media").padding(.vertical,15).padding(.horizontal, 22)
                            
                        }.background(self.selected == "Media" ? Color("Color") : Color.clear)
                        .foregroundColor(self.selected == "Media" ? .white : Color.gray)
                        .cornerRadius(15)
                        
                    }.padding(.top, 15)
                    
                    if self.selected == "About"{
                        
                        About()
                    }
                    
                    else{
                        
                        Media()
                    }
                }
                
            }.background(Rounded().fill(Color.black))
            .padding(.top, -15)
            .edgesIgnoringSafeArea(.bottom)
        }
    }
}

struct About : View {
    
    var body : some View{
        
        VStack(alignment: .leading, spacing: 15){
            
            Text("Welcome to San Francisco, the birthplace of the technological revolution. Play as young Marcus, a brilliant hacker, and join DedSec, the most celebrated hacker group. Your goal: the largest hacking operation in history.").padding(.vertical, 15)
            
            HStack{
                
                Spacer()
                
                Button(action: {
                    
                }) {
                    
                    Text("More About This Game >")
                }
            }
            
            Text("System Requirements").padding(.vertical, 15)
            
            Button(action: {
                
            }) {
                
                HStack(spacing: 10){
                    
                    Image("min")
                    
                    Text("Minimum Requirements")
                }
            }
            
            Button(action: {
                
            }) {
                
                HStack(spacing: 10){
                    
                    Image("max")
                    
                    Text("Maximum Requirements")
                }
                
            }.padding(.top, 15)
            
            Spacer()
            
        }.padding(.horizontal,25)
        .foregroundColor(Color.white.opacity(0.6))
    }
}

struct Media : View {
    
    var body : some View{
        
        VStack(alignment: .leading, spacing: 15){
            
            Text("Images")
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15){
                    
                    ForEach(detail,id: \.self){i in
                        
                        Image(i)
                    }
                }
                
            }.padding(.top,15)
            
            Text("Videos")
            
            ZStack{
                
                Image("d3")
                
                Button(action: {
                    
                }) {
                    
                    Image(systemName: "play.circle.fill").font(.largeTitle)
                    
                }.foregroundColor(.white)
                
            }.padding(.top, 15)
            
            Spacer()
            
        }.padding(.horizontal, 25)
        .foregroundColor(Color.white.opacity(0.6))
    }
}


struct Rounded : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft,.topRight], cornerRadii: CGSize(width: 25, height: 25))
        
        return Path(path.cgPath)
    }
}

// sample data.....

var top = ["Card1","Card2"]
var middle = ["m1","m2","m3"]
var bottom = ["b1","b2","b3"]
var detail = ["d1","d2"]
